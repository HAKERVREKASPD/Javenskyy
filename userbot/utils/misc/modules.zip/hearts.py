# ©️ Spribe Userbot, 2023
# This file is a part of Spribe Userbot
# >> https://github.com/Pr0n1xGH/spribe-userbot
# You can redistribute it and/or modify it under the terms of the GNU AGPLv3
# >> https://www.gnu.org/licenses/agpl-3.0.html

from asyncio import sleep

from pyrogram import Client, filters

from .help import add_command_help


@Client.on_message(filters.command("magic", prefixes=".") & filters.me)
async def smagic(client, message):
	await message.edit(f'''
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍❤️❤️🤍❤️❤️🤍🤍
	🤍❤️❤️❤️❤️❤️❤️❤️🤍 
	🤍❤️❤️❤️❤️❤️❤️❤️🤍
	🤍❤️❤️❤️❤️❤️❤️❤️🤍
	🤍🤍❤️❤️❤️❤️❤️🤍🤍
	🤍🤍🤍❤️❤️❤️🤍🤍🤍
	🤍🤍🤍🤍❤️🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍🧡🧡🤍🧡🧡🤍🤍
	🤍🧡🧡🧡🧡🧡🧡🧡🤍
	🤍🧡🧡🧡🧡🧡🧡🧡🤍 
	🤍🧡🧡🧡🧡🧡🧡🧡🤍
	🤍🤍🧡🧡🧡🧡🧡🤍🤍
	🤍🤍🤍🧡🧡🧡🤍🤍🤍
	🤍🤍🤍🤍🧡🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍💛💛🤍💛💛🤍🤍
	🤍💛💛💛💛💛💛💛🤍
	🤍💛💛💛💛💛💛💛🤍
	🤍💛💛💛💛💛💛💛🤍
	🤍🤍💛💛💛💛💛🤍🤍
	🤍🤍🤍💛💛💛🤍🤍🤍
	🤍🤍🤍🤍💛🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍💚💚🤍💚💚🤍🤍
	🤍💚💚💚💚💚💚💚🤍
	🤍💚💚💚💚💚💚💚🤍
	🤍💚💚💚💚💚💚💚🤍
	🤍🤍💚💚💚💚💚🤍🤍
	🤍🤍🤍💚💚💚🤍🤍🤍
	🤍🤍🤍🤍💚🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍💙💙🤍💙💙🤍🤍
	🤍💙💙💙💙💙💙💙🤍
	🤍💙💙💙💙💙💙💙🤍
	🤍💙💙💙💙💙💙💙🤍
	🤍🤍💙💙💙💙💙🤍🤍
	🤍🤍🤍💙💙💙🤍🤍🤍
	🤍🤍🤍🤍💙🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍💜💜🤍💜💜🤍🤍
	🤍💜💜💜💜💜💜💜🤍
	🤍💜💜💜💜💜💜💜🤍
	🤍💜💜💜💜💜💜💜🤍
	🤍🤍💜💜💜💜💜🤍🤍
	🤍🤍🤍💜💜💜🤍🤍🤍
	🤍🤍🤍🤍💜🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍💚🧡🤍💛🧡🤍🤍
	🤍🧡🧡💜🧡💚💙💛🤍
	🤍💛💚💙💚💜💚💜🤍
	🤍💙💛💜🧡🧡💚💛🤍
	🤍🤍🧡💚🧡💚💙🤍🤍
	🤍🤍🤍💜💛💜🤍🤍🤍
	🤍🤍🤍🤍💛🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍💚🧡🤍❤️🧡🤍🤍
	🤍💙❤️💜❤️💚💙💛🤍
	🤍💛💚💙💚💜💚❤️🤍
	🤍💙❤️💜❤️💙💚💙🤍
	🤍🤍🧡💚🧡❤️💙🤍🤍
	🤍🤍🤍❤️💛💜🤍🤍🤍
	🤍🤍🤍🤍💛🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍💛❤️🤍💛💛🤍🤍
	🤍💙❤️💜💛❤️💙💛🤍
	🤍❤️💚❤️💚💜💚❤️🤍
	🤍💙❤️💜❤️❤️💚💙🤍
	🤍🤍💛💚🧡💛❤️🤍🤍
	🤍🤍🤍❤️💛💜🤍🤍🤍
	🤍🤍🤍🤍💛🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍💚🧡🤍💛🧡🤍🤍
	🤍🧡🧡💜🧡💚💙💛🤍
	🤍💛💚💙💚💜💚💜🤍
	🤍💙💛💜🧡🧡💚💛🤍
	🤍🤍🧡💚🧡💚💙🤍🤍
	🤍🤍🤍💜💛💜🤍🤍🤍
	🤍🤍🤍🤍💛🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍💚🧡🤍❤️🧡🤍🤍
	🤍💙❤️💜❤️💚💙💛🤍
	🤍💛💚💙💚💜💚❤️🤍
	🤍💙❤️💜❤️💙💚💙🤍
	🤍🤍🧡💚🧡❤️💙🤍🤍
	🤍🤍🤍❤️💛💜🤍🤍🤍
	🤍🤍🤍🤍💛🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍💛❤️🤍💛💛🤍🤍
	🤍💙❤️💜💛❤️💙💛🤍
	🤍❤️💚❤️💚💜💚❤️🤍
	🤍💙❤️💜❤️❤️💚💙🤍
	🤍🤍💛💚🧡💛❤️🤍🤍
	🤍🤍🤍❤️💛💜🤍🤍🤍
	🤍🤍🤍🤍💛🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	🤍🤍🤍🤍🤍🤍🤍🤍🤍
	🤍🤍❤️❤️🤍❤️❤️🤍🤍
	🤍❤️❤️❤️❤️❤️❤️❤️🤍
	🤍❤️❤️❤️❤️❤️❤️❤️🤍
	🤍❤️❤️❤️❤️❤️❤️❤️🤍
	🤍🤍❤️❤️❤️❤️❤️🤍🤍
	🤍🤍🤍❤️❤️❤️🤍🤍🤍
	🤍🤍🤍🤍❤️🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️❤️❤️🤍🤍🤍🤍🤍🤍
	🤍🤍❤️❤️🤍❤️❤️🤍🤍
	🤍❤️❤️❤️❤️❤️❤️❤️🤍
	🤍❤️❤️❤️❤️❤️❤️❤️🤍
	🤍❤️❤️❤️❤️❤️❤️❤️🤍
	🤍🤍❤️❤️❤️❤️❤️🤍🤍
	🤍🤍🤍❤️❤️❤️🤍🤍🤍
	🤍🤍🤍🤍❤️🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️❤️❤️❤️❤️❤️❤️🤍🤍
	🤍🤍❤️❤️🤍❤️❤️🤍🤍
	🤍❤️❤️❤️❤️❤️❤️❤️🤍
	🤍❤️❤️❤️❤️❤️❤️❤️🤍
	🤍❤️❤️❤️❤️❤️❤️❤️🤍
	🤍🤍❤️❤️❤️❤️❤️🤍🤍
	🤍🤍🤍❤️❤️❤️🤍🤍🤍
	🤍🤍🤍🤍❤️🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️🤍❤️❤️🤍🤍
	🤍❤️❤️❤️❤️❤️❤️❤️🤍
	🤍❤️❤️❤️❤️❤️❤️❤️🤍
	🤍❤️❤️❤️❤️❤️❤️❤️🤍
	🤍🤍❤️❤️❤️❤️❤️🤍🤍
	🤍🤍🤍❤️❤️❤️🤍🤍🤍
	🤍🤍🤍🤍❤️🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️🤍
	🤍❤️❤️❤️❤️❤️❤️❤️🤍
	🤍🤍❤️❤️❤️❤️❤️🤍🤍
	🤍🤍🤍❤️❤️❤️🤍🤍🤍
	🤍🤍🤍🤍❤️🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️🤍🤍
	🤍🤍🤍❤️❤️❤️🤍🤍🤍
	🤍🤍🤍🤍❤️🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	🤍🤍🤍🤍❤️🤍🤍🤍🤍
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	🤍🤍🤍🤍🤍🤍🤍🤍🤍''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️❤️''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️❤️''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️❤️''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️❤️''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️
	❤️❤️❤️❤️❤️''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️❤️❤️❤️
	❤️❤️❤️❤️
	❤️❤️❤️❤️
	❤️❤️❤️❤️''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️❤️❤️
	❤️❤️❤️
	❤️❤️❤️''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️❤️
	❤️❤️''')
	await sleep(0.6) 
	await message.edit(f'''
	❤️''')


@Client.on_message(filters.command("loveyou", ".") & filters.me)
async def sloveyou(client, message):
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝''')
	await sleep(0.4)
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝
💘💘❤️❤️💘❤️❤️💘💘
''')
	await sleep(0.4)
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝
💘💘❤️❤️💘❤️❤️💘💘
🖤❤️❤️❤️❤️❤️❤️❤️🖤
''')
	await sleep(0.4)
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝
💘💘❤️❤️💘❤️❤️💘💘
🖤❤️❤️❤️❤️❤️❤️❤️🖤
🤎❤️❤️❤️❤️❤️❤️❤️🤎
''')
	await sleep(0.4)
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝
💘💘❤️❤️💘❤️❤️💘💘
🖤❤️❤️❤️❤️❤️❤️❤️🖤
🤎❤️❤️❤️❤️❤️❤️❤️🤎
🧡❤️❤️❤️❤️❤️❤️❤️🧡
''')
	await sleep(0.4)
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝
💘💘❤️❤️💘❤️❤️💘💘
🖤❤️❤️❤️❤️❤️❤️❤️🖤
🤎❤️❤️❤️❤️❤️❤️❤️🤎
🧡❤️❤️❤️❤️❤️❤️❤️🧡
💛💛❤️❤️❤️❤️❤️💛💛
''')
	await sleep(0.4)
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝
💘💘❤️❤️💘❤️❤️💘💘
🖤❤️❤️❤️❤️❤️❤️❤️🖤
🤎❤️❤️❤️❤️❤️❤️❤️🤎
🧡❤️❤️❤️❤️❤️❤️❤️🧡
💛💛❤️❤️❤️❤️❤️💛💛
💜💜💜❤️❤️❤️💜💜💜
''')
	await sleep(0.4)
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝
💘💘❤️❤️💘❤️❤️💘💘
🖤❤️❤️❤️❤️❤️❤️❤️🖤
🤎❤️❤️❤️❤️❤️❤️❤️🤎
🧡❤️❤️❤️❤️❤️❤️❤️🧡
💛💛❤️❤️❤️❤️❤️💛💛
💜💜💜❤️❤️❤️💜💜💜
💙💙💙💙❤️💙💙💙💙
''')
	await sleep(0.4)
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝
💘💘❤️❤️💘❤️❤️💘💘
🖤❤️❤️❤️❤️❤️❤️❤️🖤
🤎❤️❤️❤️❤️❤️❤️❤️🤎
🧡❤️❤️❤️❤️❤️❤️❤️🧡
💛💛❤️❤️❤️❤️❤️💛💛
💜💜💜❤️❤️❤️💜💜💜
💙💙💙💙❤️💙💙💙💙
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝
💘💘❤️❤️💘❤️❤️💘💘
🖤❤️❤️❤️❤️❤️❤️❤️🖤
🤎❤️❤️❤️❤️❤️❤️❤️🤎
🧡❤️❤️❤️❤️❤️❤️❤️🧡
💛💛❤️❤️❤️❤️❤️💛💛
💜💜💜❤️❤️❤️💜💜💜
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝
💘💘❤️❤️💘❤️❤️💘💘
🖤❤️❤️❤️❤️❤️❤️❤️🖤
🤎❤️❤️❤️❤️❤️❤️❤️🤎
🧡❤️❤️❤️❤️❤️❤️❤️🧡
💛💛❤️❤️❤️❤️❤️💛💛
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝
💘💘❤️❤️💘❤️❤️💘💘
🖤❤️❤️❤️❤️❤️❤️❤️🖤
🤎❤️❤️❤️❤️❤️❤️❤️🤎
🧡❤️❤️❤️❤️❤️❤️❤️🧡
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝
💘💘❤️❤️💘❤️❤️💘💘
🖤❤️❤️❤️❤️❤️❤️❤️🖤
🤎❤️❤️❤️❤️❤️❤️❤️🤎
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝
💘💘❤️❤️💘❤️❤️💘💘
🖤❤️❤️❤️❤️❤️❤️❤️🖤
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝
💘💘❤️❤️💘❤️❤️💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f'''
💝💝💝💝💝💝💝💝💝
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f'''
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f'''
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f'''
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f'''
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f'''
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f'''
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f'''
💘💘💘💘💘💘💘💘💘
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f'''
💘💘💘💘💘💘💘💘💘''')
	await sleep(0.4)
	await message.edit(f"I love you 💘")


@Client.on_message(filters.command("loves", ".") & filters.me)
async def sloves(client, message):
	time = 0.3
	for i in range(1):
		await message.edit(f'''
✨✨✨✨✨✨
✨❤️❤️❤️❤️✨
✨❤️✨✨❤️✨
✨❤️❤️❤️❤️✨
✨✨✨❤️❤️✨
✨✨❤️✨❤️✨
✨❤️✨✨❤️✨
✨✨✨✨✨✨''')
		await sleep(time)
		await message.edit(f'''
✨✨✨✨✨✨
✨❤️❤️❤️❤️✨
✨✨❤️❤️✨✨
✨✨❤️❤️✨✨
✨✨❤️❤️✨✨
✨✨❤️❤️✨✨
✨✨✨✨✨✨''')
		await sleep(time)
		await message.edit(f'''
✨✨✨✨✨✨
✨❤️❤️❤️❤️✨
✨❤️✨✨✨✨
✨❤️❤️❤️✨✨
✨❤️✨✨✨✨
✨❤️❤️❤️❤️✨
✨✨✨✨✨✨''')
		await sleep(time)
		await message.edit(f'''
✨✨✨✨✨✨
✨❤️❤️❤️❤️✨
✨❤️✨✨✨✨
✨❤️❤️❤️❤️✨
✨❤️✨✨❤️✨
✨❤️✨✨❤️✨
✨❤️❤️❤️❤️✨
✨✨✨✨✨✨''')
		await sleep(time)
		await message.edit(f'''
✨✨✨✨✨✨
✨❤️❤️❤️❤️✨
✨❤️✨✨❤️✨
✨❤️❤️❤️❤️✨
✨✨✨❤️❤️✨
✨✨❤️✨❤️✨
✨❤️✨✨❤️✨
✨✨✨✨✨✨''')
		await sleep(time)
		await message.edit(f'''
✨✨✨✨✨✨✨✨✨
✨✨❤️❤️✨❤️❤️✨✨
✨❤️❤️❤️❤️❤️❤️❤️✨
✨❤️❤️❤️❤️❤️❤️❤️✨
✨✨❤️❤️❤️❤️❤️✨✨
✨✨✨❤️❤️❤️✨✨✨
✨✨✨✨❤️✨✨✨✨
✨✨✨✨✨✨✨✨✨''')
		await sleep(time)
		await message.edit(f'''
✨✨✨✨✨✨✨✨✨
✨✨💚💚✨💚💚✨✨
✨💚💚💚💚💚💚💚✨
✨💚💚💚💚💚💚💚✨
✨✨💚💚💚💚💚✨✨
✨✨✨💚💚💚✨✨✨
✨✨✨✨💚✨✨✨✨
✨✨✨✨✨✨✨✨✨''')
		await sleep(time)
		await message.edit(f'''
✨✨✨✨✨✨✨✨✨
✨✨💙💙✨💙💙✨✨
✨💙💙💙💙💙💙💙✨
✨💙💙💙💙💙💙💙✨
✨✨💙💙💙💙💙✨✨
✨✨✨💙💙💙✨✨✨
✨✨✨✨💙✨✨✨✨
✨✨✨✨✨✨✨✨✨''')
		await sleep(time)
		await message.edit(f'''
✨✨✨✨✨✨✨✨✨
✨✨💜💜✨💜💜✨✨
✨💜💜💜💜💜💜💜✨
✨💜💜💜💜💜💜💜✨
✨✨💜💜💜💜💜✨✨
✨✨✨💜💜💜✨✨✨
✨✨✨✨💜✨✨✨✨
✨✨✨✨✨✨✨✨✨''')
		await sleep(time)
		await message.edit(f'''
✨✨✨✨✨✨✨✨✨
✨✨🤍🤍✨🤍🤍✨✨
✨🤍🤍🤍🤍🤍🤍🤍✨
✨🤍🤍🤍🤍🤍🤍🤍✨
✨✨🤍🤍🤍🤍🤍✨✨
✨✨✨🤍🤍🤍✨✨✨
✨✨✨✨🤍✨✨✨✨
✨✨✨✨✨✨✨✨✨''')
		await sleep(time)
		await message.edit(f'''
✨✨✨✨✨✨✨✨✨
✨✨🖤🖤✨🖤🖤✨✨
✨🖤🖤🖤🖤🖤🖤🖤✨
✨🖤🖤🖤🖤🖤🖤🖤✨
✨✨🖤🖤🖤🖤🖤✨✨
✨✨✨🖤🖤🖤✨✨✨
✨✨✨✨🖤✨✨✨✨
✨✨✨✨✨✨✨✨✨''')
		await sleep(time)
		await message.edit(f'''
✨✨✨✨✨✨✨✨✨
✨✨💛💛✨💛💛✨✨
✨💛💛💛💛💛💛💛✨
✨💛💛💛💛💛💛💛✨
✨✨💛💛💛💛💛✨✨
✨✨✨💛💛💛✨✨✨
✨✨✨✨💛✨✨✨✨
✨✨✨✨✨✨✨✨✨''')
		await sleep(time)
		await message.edit(f'''
✨✨✨✨✨✨✨✨✨
✨✨🧡🧡✨🧡🧡✨✨
✨🧡🧡🧡🧡🧡🧡🧡✨
✨🧡🧡🧡🧡🧡🧡🧡✨
✨✨🧡🧡🧡🧡🧡✨✨
✨✨✨🧡🧡🧡✨✨✨
✨✨✨✨🧡✨✨✨✨
✨✨✨✨✨✨✨✨✨''')
		await message.delete()


@Client.on_message(filters.command("heart", ".") & filters.me)
async def sheart(client, message):
	time = 0.3
	for i in range(1):
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍❤️❤️🤍❤️❤️🤍🤍\n🤍❤️❤️❤️❤️❤️❤️❤️🤍\n🤍🤍❤️❤️❤️❤️❤️🤍🤍\n🤍🤍🤍❤️❤️❤️🤍🤍🤍\n🤍🤍🤍🤍❤️🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # red
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍🧡🧡🤍🧡🧡🤍🤍\n🤍🧡🧡🧡🧡🧡🧡🧡🤍\n🤍🤍🧡🧡🧡🧡🧡🤍🤍\n🤍🤍🤍🧡🧡🧡🤍🤍🤍\n🤍🤍🤍🤍🧡🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # orange
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💛💛🤍💛💛🤍🤍\n🤍💛💛💛💛💛💛💛🤍\n🤍🤍💛💛💛💛💛🤍🤍\n🤍🤍🤍💛💛💛🤍🤍🤍\n🤍🤍🤍🤍💛🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # yellow
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💚💚🤍💚💚🤍🤍\n🤍💚💚💚💚💚💚💚🤍\n🤍🤍💚💚💚💚💚🤍🤍\n🤍🤍🤍💚💚💚🤍🤍🤍\n🤍🤍🤍🤍💚🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # green
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💙💙🤍💙💙🤍🤍\n🤍💙💙💙💙💙💙💙🤍\n🤍🤍💙💙💙💙💙🤍🤍\n🤍🤍🤍💙💙💙🤍🤍🤍\n🤍🤍🤍🤍💙🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # blue
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💜💜🤍💜💜🤍🤍\n🤍💜💜💜💜💜💜💜🤍\n🤍🤍💜💜💜💜💜🤍🤍\n🤍🤍🤍💜💜💜🤍🤍🤍\n🤍🤍🤍🤍💜🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # purple
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍🖤🖤🤍🖤🖤🤍🤍\n🤍🖤🖤🖤🖤🖤🖤🖤🤍\n🤍🤍🖤🖤🖤🖤🖤🤍🤍\n🤍🤍🤍🖤🖤🖤🤍🤍🤍\n🤍🤍🤍🤍🖤🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # black
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍❤️❤️🤍❤️❤️🤍🤍\n🤍❤️❤️❤️❤️❤️❤️❤️🤍\n🤍🤍❤️❤️❤️❤️❤️🤍🤍\n🤍🤍🤍❤️❤️❤️🤍🤍🤍\n🤍🤍🤍🤍❤️🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # red
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍🧡🧡🤍🧡🧡🤍🤍\n🤍🧡🧡🧡🧡🧡🧡🧡🤍\n🤍🤍🧡🧡🧡🧡🧡🤍🤍\n🤍🤍🤍🧡🧡🧡🤍🤍🤍\n🤍🤍🤍🤍🧡🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # orange
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💛💛🤍💛💛🤍🤍\n🤍💛💛💛💛💛💛💛🤍\n🤍🤍💛💛💛💛💛🤍🤍\n🤍🤍🤍💛💛💛🤍🤍🤍\n🤍🤍🤍🤍💛🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # yellow
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💚💚🤍💚💚🤍🤍\n🤍💚💚💚💚💚💚💚🤍\n🤍🤍💚💚💚💚💚🤍🤍\n🤍🤍🤍💚💚💚🤍🤍🤍\n🤍🤍🤍🤍💚🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # green
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💙💙🤍💙💙🤍🤍\n🤍💙💙💙💙💙💙💙🤍\n🤍🤍💙💙💙💙💙🤍🤍\n🤍🤍🤍💙💙💙🤍🤍🤍\n🤍🤍🤍🤍💙🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # blue
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💜💜🤍💜💜🤍🤍\n🤍💜💜💜💜💜💜💜🤍\n🤍🤍💜💜💜💜💜🤍🤍\n🤍🤍🤍💜💜💜🤍🤍🤍\n🤍🤍🤍🤍💜🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # purple
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍🖤🖤🤍🖤🖤🤍🤍\n🤍🖤🖤🖤🖤🖤🖤🖤🤍\n🤍🤍🖤🖤🖤🖤🖤🤍🤍\n🤍🤍🤍🖤🖤🖤🤍🤍🤍\n🤍🤍🤍🤍🖤🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # black
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍❤️❤️🤍❤️❤️🤍🤍\n🤍❤️❤️❤️❤️❤️❤️❤️🤍\n🤍🤍❤️❤️❤️❤️❤️🤍🤍\n🤍🤍🤍❤️❤️❤️🤍🤍🤍\n🤍🤍🤍🤍❤️🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # red
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍🧡🧡🤍🧡🧡🤍🤍\n🤍🧡🧡🧡🧡🧡🧡🧡🤍\n🤍🤍🧡🧡🧡🧡🧡🤍🤍\n🤍🤍🤍🧡🧡🧡🤍🤍🤍\n🤍🤍🤍🤍🧡🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # orange
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💛💛🤍💛💛🤍🤍\n🤍💛💛💛💛💛💛💛🤍\n🤍🤍💛💛💛💛💛🤍🤍\n🤍🤍🤍💛💛💛🤍🤍🤍\n🤍🤍🤍🤍💛🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # yellow
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💚💚🤍💚💚🤍🤍\n🤍💚💚💚💚💚💚💚🤍\n🤍🤍💚💚💚💚💚🤍🤍\n🤍🤍🤍💚💚💚🤍🤍🤍\n🤍🤍🤍🤍💚🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # green
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💙💙🤍💙💙🤍🤍\n🤍💙💙💙💙💙💙💙🤍\n🤍🤍💙💙💙💙💙🤍🤍\n🤍🤍🤍💙💙💙🤍🤍🤍\n🤍🤍🤍🤍💙🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # blue
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💜💜🤍💜💜🤍🤍\n🤍💜💜💜💜💜💜💜🤍\n🤍🤍💜💜💜💜💜🤍🤍\n🤍🤍🤍💜💜💜🤍🤍🤍\n🤍🤍🤍🤍💜🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # purple
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍🖤🖤🤍🖤🖤🤍🤍\n🤍🖤🖤🖤🖤🖤🖤🖤🤍\n🤍🤍🖤🖤🖤🖤🖤🤍🤍\n🤍🤍🤍🖤🖤🖤🤍🤍🤍\n🤍🤍🤍🤍🖤🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # black
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍❤️❤️🤍❤️❤️🤍🤍\n🤍❤️❤️❤️❤️❤️❤️❤️🤍\n🤍🤍❤️❤️❤️❤️❤️🤍🤍\n🤍🤍🤍❤️❤️❤️🤍🤍🤍\n🤍🤍🤍🤍❤️🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # red
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍🧡🧡🤍🧡🧡🤍🤍\n🤍🧡🧡🧡🧡🧡🧡🧡🤍\n🤍🤍🧡🧡🧡🧡🧡🤍🤍\n🤍🤍🤍🧡🧡🧡🤍🤍🤍\n🤍🤍🤍🤍🧡🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # orange
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💛💛🤍💛💛🤍🤍\n🤍💛💛💛💛💛💛💛🤍\n🤍🤍💛💛💛💛💛🤍🤍\n🤍🤍🤍💛💛💛🤍🤍🤍\n🤍🤍🤍🤍💛🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # yellow
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💚💚🤍💚💚🤍🤍\n🤍💚💚💚💚💚💚💚🤍\n🤍🤍💚💚💚💚💚🤍🤍\n🤍🤍🤍💚💚💚🤍🤍🤍\n🤍🤍🤍🤍💚🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # green
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💙💙🤍💙💙🤍🤍\n🤍💙💙💙💙💙💙💙🤍\n🤍🤍💙💙💙💙💙🤍🤍\n🤍🤍🤍💙💙💙🤍🤍🤍\n🤍🤍🤍🤍💙🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # blue
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💜💜🤍💜💜🤍🤍\n🤍💜💜💜💜💜💜💜🤍\n🤍🤍💜💜💜💜💜🤍🤍\n🤍🤍🤍💜💜💜🤍🤍🤍\n🤍🤍🤍🤍💜🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # purple
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍🖤🖤🤍🖤🖤🤍🤍\n🤍🖤🖤🖤🖤🖤🖤🖤🤍\n🤍🤍🖤🖤🖤🖤🖤🤍🤍\n🤍🤍🤍🖤🖤🖤🤍🤍🤍\n🤍🤍🤍🤍🖤🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # black
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍❤️❤️🤍❤️❤️🤍🤍\n🤍❤️❤️❤️❤️❤️❤️❤️🤍\n🤍🤍❤️❤️❤️❤️❤️🤍🤍\n🤍🤍🤍❤️❤️❤️🤍🤍🤍\n🤍🤍🤍🤍❤️🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # red
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍🧡🧡🤍🧡🧡🤍🤍\n🤍🧡🧡🧡🧡🧡🧡🧡🤍\n🤍🤍🧡🧡🧡🧡🧡🤍🤍\n🤍🤍🤍🧡🧡🧡🤍🤍🤍\n🤍🤍🤍🤍🧡🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # orange
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💛💛🤍💛💛🤍🤍\n🤍💛💛💛💛💛💛💛🤍\n🤍🤍💛💛💛💛💛🤍🤍\n🤍🤍🤍💛💛💛🤍🤍🤍\n🤍🤍🤍🤍💛🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # yellow
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💚💚🤍💚💚🤍🤍\n🤍💚💚💚💚💚💚💚🤍\n🤍🤍💚💚💚💚💚🤍🤍\n🤍🤍🤍💚💚💚🤍🤍🤍\n🤍🤍🤍🤍💚🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # green
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💙💙🤍💙💙🤍🤍\n🤍💙💙💙💙💙💙💙🤍\n🤍🤍💙💙💙💙💙🤍🤍\n🤍🤍🤍💙💙💙🤍🤍🤍\n🤍🤍🤍🤍💙🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # blue
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💜💜🤍💜💜🤍🤍\n🤍💜💜💜💜💜💜💜🤍\n🤍🤍💜💜💜💜💜🤍🤍\n🤍🤍🤍💜💜💜🤍🤍🤍\n🤍🤍🤍🤍💜🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # purple
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍🖤🖤🤍🖤🖤🤍🤍\n🤍🖤🖤🖤🖤🖤🖤🖤🤍\n🤍🤍🖤🖤🖤🖤🖤🤍🤍\n🤍🤍🤍🖤🖤🖤🤍🤍🤍\n🤍🤍🤍🤍🖤🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # black
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍❤️❤️🤍❤️❤️🤍🤍\n🤍❤️❤️❤️❤️❤️❤️❤️🤍\n🤍🤍❤️❤️❤️❤️❤️🤍🤍\n🤍🤍🤍❤️❤️❤️🤍🤍🤍\n🤍🤍🤍🤍❤️🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # red
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍🧡🧡🤍🧡🧡🤍🤍\n🤍🧡🧡🧡🧡🧡🧡🧡🤍\n🤍🤍🧡🧡🧡🧡🧡🤍🤍\n🤍🤍🤍🧡🧡🧡🤍🤍🤍\n🤍🤍🤍🤍🧡🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # orange
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💛💛🤍💛💛🤍🤍\n🤍💛💛💛💛💛💛💛🤍\n🤍🤍💛💛💛💛💛🤍🤍\n🤍🤍🤍💛💛💛🤍🤍🤍\n🤍🤍🤍🤍💛🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # yellow
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💚💚🤍💚💚🤍🤍\n🤍💚💚💚💚💚💚💚🤍\n🤍🤍💚💚💚💚💚🤍🤍\n🤍🤍🤍💚💚💚🤍🤍🤍\n🤍🤍🤍🤍💚🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # green
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💙💙🤍💙💙🤍🤍\n🤍💙💙💙💙💙💙💙🤍\n🤍🤍💙💙💙💙💙🤍🤍\n🤍🤍🤍💙💙💙🤍🤍🤍\n🤍🤍🤍🤍💙🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # blue
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍💜💜🤍💜💜🤍🤍\n🤍💜💜💜💜💜💜💜🤍\n🤍🤍💜💜💜💜💜🤍🤍\n🤍🤍🤍💜💜💜🤍🤍🤍\n🤍🤍🤍🤍💜🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # purple
		await sleep(time)
		await message.edit(f"🤍🤍🤍🤍🤍🤍🤍🤍🤍\n🤍🤍🖤🖤🤍🖤🖤🤍🤍\n🤍🖤🖤🖤🖤🖤🖤🖤🤍\n🤍🤍🖤🖤🖤🖤🖤🤍🤍\n🤍🤍🤍🖤🖤🖤🤍🤍🤍\n🤍🤍🤍🤍🖤🤍🤍🤍🤍\n🤍🤍🤍🤍🤍🤍🤍🤍🤍\n")  # black
		await sleep(1)
		await message.delete()


add_command_help(
	"hearts",
	[
		[".magic", "Анимация сердца"],
		[".loveyou", "Анимация сердца №2"],
		[".loves", "Анимация сердца №3"],
		[".heart", "Анимация сердца №4"],
	],
)